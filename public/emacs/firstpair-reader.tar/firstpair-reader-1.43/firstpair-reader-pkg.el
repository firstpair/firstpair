;;; firstpair-reader-pkg.el --- package definition  -*- lexical-binding: t; -*-
(define-package "firstpair-reader" "1.43" "Read FirstPair books in Emacs Info"
  '((emacs "27.1"))
  :keywords '("docs" "hypermedia")
  :url "https://firstpair.org/emacs/")

;; Local Variables:
;; no-byte-compile: t
;; End:
